#!/bin/bash

while true
do
./wildrig-multi --print-full --algo x25x --url stratum+tcp://eupool.sinovate.io:3253 --user SauLQKggrWaAcFU8BvZCJ2bEHAYb8QdpQY --pass c=SIN
sleep 5
done

#!/bin/bash

while true
do
./wildrig-multi --print-full --algo vprogpow --url stratum+tcp://veriblock.luckypool.io:9501 --user VHoWCZrQB4kqLHm1EoNoU8rih7ohyG --pass x
sleep 5
done

#!/bin/bash

while true
do
./wildrig-multi --print-full --algo 0x10 --url stratum+tcp://gpus.anomp.cc:30011 --user 5Xk6HoY4aB2zMSj4budzvDigfj1rGHivZD --pass x
sleep 5
done

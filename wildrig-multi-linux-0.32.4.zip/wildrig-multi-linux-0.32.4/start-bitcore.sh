#!/bin/bash

while true
do
./wildrig-multi --print-full --algo megabtx --url stratum+tcp://stratum-eu.rplant.xyz:17066 --user sY7v3ieNguMPRd8XkzGdUtASDZFrCvdAmn --pass x
sleep 5
done